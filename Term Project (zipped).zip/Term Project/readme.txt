Project Name: Physics Simulator

With this physics simulator, you’re able to change what
you want to change--mass, height, or velocity--depending on which scenario you 
pick. And you’ll be able to see relevant graphs from the visualization.
Experiment with the different parameters.

You only need to run "termTest.py" from my "Term Project" folder.

I've included the CMU 112 Graphics module file in my folder, so you don't to do
anything else for this part.

No shortcuts except pressing "q" to quit to go back to main menu or "r" to
restart the mode that you're on.
